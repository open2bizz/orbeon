# -*- coding: utf-8 -*-
##############################################################################
# Copyright Open2Bizz 2025
# GNU LESSER GENERAL PUBLIC LICENSE
# Version 3, 29 June 2007
#
# Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
# Everyone is permitted to copy and distribute verbatim copies
# of this license document, but changing it is not allowed.
#
#
# This version of the GNU Lesser General Public License incorporates
# the terms and conditions of version 3 of the GNU General Public
# License, supplemented by the additional permissions listed in the following URL:
# https://www.gnu.org/licenses/lgpl.txt.
#
##############################################################################
from odoo import models, fields, api
from odoo.exceptions import ValidationError,UserError

from lxml import etree

import re

import logging
_logger = logging.getLogger(__name__)

STATE_CURRENT = 'current'
STATE_NEW = 'new'
STATE_OBSOLETE = 'obsolete'



class OrbeonBuilder(models.Model):
    _name = 'orbeon.master'
    _description = 'Orbeon Master Version'

    master_builder_id = fields.Many2one('orbeon.builder', string="Master Builder")
    slave_ids = fields.One2many('orbeon.builder','master_id', string="Slave Builders")
    display_name = fields.Char("Name", compute="_set_name")

    def _set_name(self):
        for master in self:
            b_name = master.master_builder_id.complete_name or "Unknown"
            master.display_name = "Master " + "(" + b_name + ")"

class OrbeonBuilder(models.Model):
    _name = 'orbeon.builder'
    _inherit = ['mail.thread']
    _description = 'Orbeon Builder'

    _order = 'res_model_id DESC, name ASC, version ASC'
    _rec_name = 'complete_name'

    name = fields.Char(
        "Name",
        required=True,
        help="""
        Identifies this specific form (e.g. "health-record" or "claim").
        This name can be used in APIs, so we recommend you use only lowercases characters.""",
    )

    title = fields.Char(
        "Title",
        help="Form title in the current language",
        default="Untitled Form"
    )

    description = fields.Text(
        "Description",
        help="Form description in the current language")

    complete_name = fields.Char(
        "Full Name",
        compute='_compute_complete_name',
        store=True
    )

    parent_id = fields.Many2one(
        'orbeon.builder',
        string='Parent Version',
        readonly=True
    )

    version = fields.Integer(
        "Version",
        required=True,
        readonly=True,
        default=1)

    version_comment = fields.Text(
        "Version Comment",
        required=True)

    state = fields.Selection(
        [
            (STATE_NEW, "New"),
            (STATE_CURRENT, "Current"),
            (STATE_OBSOLETE, "Obsolete"),
        ],
        "State",
        default=STATE_NEW,
        required=True,
        help="""\
        - New: In draft and was never published (Current)
        - Current: Published i.e. live
        - Obsolete: Was published but obsolete"""
    )

    xml = fields.Text(
        'XML')

    server_id = fields.Many2one(
        "orbeon.server",
        "Server",
        required=True,
        ondelete='restrict')

    builder_template_id = fields.Many2one(
        "orbeon.builder.template",
        "Builder Form Template",
        ondelete='set null',
        copy=False,
        help="By default some Builder Form Templates are shipped by the Orbeon Server."
    )

    runner_form_ids = fields.One2many(
        "orbeon.runner",
        "builder_id",
        string="Form runners")

    res_model_id = fields.Many2one(
        "ir.model",
        "Resource Model",
        help="Model as resource this form represents or acts on"
    )

    url = fields.Text(
        'URL',
        compute="_get_url",
        readonly=True)

    current_builder_id = fields.Many2one(
        "orbeon.builder",
        "Current Builder",
        compute="_current_builder",
        help="The current (published) Builder"
    )

    debug_mode = fields.Boolean(
        'Debug Mode',
        default=False,
        help="Shows debug info (by field) in Orbeon Runner Form.\r\nAdds debug-info as messages (by field) on the Runner record."
    )

    master_id = fields.Many2one("orbeon.master", string="Master Builder", help='This field links the first ever version of this builder will all the newly created builders.')

    def init(self):
        if self.env['ir.model'].search([('model','=','orbeon.master')]) and self.env['ir.model'].search([('model','=','orbeon.builder')]):
            for builder in self.env['orbeon.builder'].search([('parent_id','=',False)]):
                master_record = self.env['orbeon.master'].search([('master_builder_id','=',builder.id)])
                
                if not master_record:
                    master_record = self.env['orbeon.master'].create({'master_builder_id' : builder.id})
                slave_ids = self.env['orbeon.builder'].search([('id','child_of',master_record.master_builder_id.id),('id','!=',master_record.master_builder_id.id)])
                master_record.slave_ids = [(6,0, slave_ids.ids)]
                    
                    

    @api.depends('title', 'name', 'version')
    def _compute_complete_name(self):
        for record in self:
            record.complete_name = "%s (%s @ %s @ %s)" % (record.title, record.name, record.state, record.version)

    
    @api.constrains('name')
    def constaint_check_name(self):
        if re.search(r"[^a-zA-Z0-9_-]", self.name) is not None:
            raise ValidationError('Name is invalid. Use ASCII letters, digits, "-" or "_"')

    
    @api.constrains("name", "state")
    def constraint_one_current(self):
        """Per name there can be only 1 record with
        state current at a time.
        """
        cur_record = self.search([
            ("name", "=", self.name),
            ("state", "=", STATE_CURRENT)
            ])
        if len(cur_record) > 1:
            raise ValidationError("%s already has a record with status 'current'.\
                    Only one builder form can be current at a time." % self.name)

    
    @api.constrains("name", "version")
    def constraint_one_version(self):
        """Per name there can be only 1 record with
        same version at a time.
        """

        domain = [('name', '=', self.name)]
        name_version_grouped = self.read_group(domain, ['version'], ['version'])

        if name_version_grouped[0]['version_count'] > 1:
            raise ValidationError("%s already has a record with version: %d"
                                  % (self.name, self.version))

    def validate_create_xml(self, vals):
        if vals.get('builder_template_id', False) and vals.get('xml', False):
            raise ValidationError("Provide either a \"Builder Form Template\" or XML. Both not allowed.")

        if not vals.get('builder_template_id', False) and not vals.get('xml', False):
            raise ValidationError("Missing either a \"Builder Form Template\" or XML")

    @api.model
    def create(self, vals):
        self.validate_create_xml(vals)

        if vals.get('builder_template_id', False):
            template = self.env['orbeon.builder.template'].browse(vals['builder_template_id'])
            root = etree.fromstring(template.xml)
        elif 'xml' in vals:
            xml = u"%s" % vals['xml']
            xml = bytes(bytearray(xml, encoding='utf-8'))

            root = etree.fromstring(xml)

        if len(root.xpath('//application-name')) > 0:
            root.xpath('//application-name')[0].text = 'odoo'

        if 'name' in vals and len(root.xpath('//form-name')) > 0:
            root.xpath('//form-name')[0].text = vals['name']

        if 'title' in vals and vals['title']:
            root.xpath('//metadata/title')[0].text = vals['title']

            if len(root.xpath('//title')) > 0:
                root.xpath('//title')[0].text = vals['title']

            if len(root.xpath('//xh:title', namespaces={'xh': "http://www.w3.org/1999/xhtml"})) > 0:
                root.xpath('//xh:title', namespaces={'xh': "http://www.w3.org/1999/xhtml"})[0].text = vals['title']

        vals['xml'] = etree.tostring(root, encoding='unicode')

        res = super(OrbeonBuilder, self).create(vals)
        if 'parent_id' not in vals:
            master_record = self.env['orbeon.master'].create({'master_builder_id': res.id})
        if 'parent_id' in vals:
            master_record = self.env['orbeon.master'].search([('master_builder_id', '=', vals['parent_id'])])
        if master_record:
            res.master_id = master_record.id

        return res

    
    @api.returns('self', lambda value: value)
    def copy_as_new_version(self):
        """Get last version for builder-forms by traversing-up on parent_id"""

        builder = self

        while builder.parent_id:
            builder = builder.parent_id

        builder = self.search([('id', 'child_of', builder.id)], limit=1, order='id DESC')

        alter = {}
        alter["parent_id"] = self.id
        alter["state"] = STATE_NEW
        alter["version"] = builder.version + 1
        alter["builder_template_id"] = False


        res = super(OrbeonBuilder, self).copy(alter)

        return res

    
    def new_version_builder_form(self):
        res = self.copy_as_new_version()

        form_view = self.env["ir.ui.view"].search(
            [("name", "=", "orbeon.builder_form.form")]
        )[0]

        tree_view = self.env["ir.ui.view"].search(
            [("name", "=", "orbeon.builder_form.tree")]
        )[0]

        return {
            "name": self.name,
            "type": "ir.actions.act_window",
            "res_model": "orbeon.builder",
            "view_mode": "form, list",
            "views": [
                [form_view.id, "form"],
                [list_view.id, "list"],
            ],
            "target": "current",
            "res_id": res.id,
            "context": {}
        }

    
    def open_orbeon_builder_form(self):
        return {
            "name": 'Orbeon',
            "type": "ir.actions.act_url",
            "target": "new",
            'url': self.url
        }

    
    def _get_url(self):
        self.ensure_one()
        if isinstance(self.id, models.NewId):
            return {}

        if hasattr(self, '_origin') and not isinstance(self._origin.id, models.NewId):
            builder_id = self._origin.id
        else:
            builder_id = self.id

        builder_url = "/orbeon/%s" % ("fr/orbeon/builder")
        get_mode = {STATE_NEW: 'edit'}
        url = "%s/%s/%i" % (builder_url, get_mode.get(self.state, 'view'), builder_id)

        self.url = url

    
    def _current_builder(self):
        for record in self:
            query = """WITH RECURSIVE
                builder_children AS (
                SELECT
                    id, parent_id, name, state
                FROM
                    orbeon_builder
                WHERE id = {builder_id}
                    UNION ALL
                SELECT
                    ob.id, ob.parent_id, ob.name, ob.state
                FROM
                    builder_children AS bc
                    INNER JOIN orbeon_builder AS ob ON ob.parent_id = bc.id
                )
                SELECT id AS builder_id
                FROM builder_children
                WHERE state = '{state}' LIMIT 1
            """.format(builder_id=record.id, state=STATE_CURRENT)

            record.env.cr.execute(query)

            builder_id = record.env.cr.fetchone()
            if builder_id:
                record.current_builder_id = record.browse(builder_id[0])
            else:
                record.current_builder_id = False
                raise UserError("Er is geen huidige versie van het formulier ontwerp, neem contact op met de systeembeheerder!")

    @api.model
    def orbeon_search_read_data(self, domain=None, fields=None):
        builder = self.search(domain or [], limit=1)

        res = {'id': builder['id']}

        for f in fields:
            res[f] = builder[f]

        return res

    
    def get_xml_form_node(self):
        parser = etree.XMLParser(ns_clean=True, encoding='utf-8')


        # Cast to string, to prevent Unicode error!
        root = etree.XML(self.xml.encode('utf-8'), parser)
        form_node = root.xpath(
            "//xf:instance[@id='fr-form-instance']/form",
            namespaces={'xf': "http://www.w3.org/2002/xforms"}
        )[0]
        form = etree.XML(etree.tostring(form_node, encoding='unicode'), parser)
        etree.cleanup_namespaces(form)

        return etree.tostring(form, encoding='unicode')

    def view_runner_forms(self):
        self.ensure_one()
        action = self.env["ir.actions.actions"]._for_xml_id("orbeon.orbeon_runner_form_action")
        action['domain'] = [
            ('builder_id', '=', self.id)
        ]
        action['context'] = {'default_builder_id': self.id}
        return action
